import { Component, OnInit } from '@angular/core';
import { PROMPTS } from 'src/prompts';
@Component({
  selector: 'app-promptdisplay',
  templateUrl: './promptdisplay.component.html',
  styleUrls: ['./promptdisplay.component.css']
})
export class PromptdisplayComponent implements OnInit {
  prompts:string[] = PROMPTS;
  currentPromptIndex:number = 0;
  prompt:string = this.prompts[this.currentPromptIndex];


  constructor() { }
 
  ngOnInit(): void {
  }
  nextPrompt():void{
    this.currentPromptIndex = (this.currentPromptIndex+1)%this.prompts.length;
    this.prompt = this.prompts[this.currentPromptIndex];
  }
}
