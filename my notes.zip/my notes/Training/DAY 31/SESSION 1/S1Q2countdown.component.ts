import { Component, OnInit } from '@angular/core';
 
@Component({
  selector: 'app-countdown',
  templateUrl: './countdown.component.html',
  styleUrls: ['./countdown.component.css']
})
export class CountdownComponent implements OnInit {
  countdown:number;
  intervalid:any;
  constructor() {
    this.countdown = 0;
   }

  ngOnInit(): void {
  }
  startCountdown(seconds:number):void{
     this.countdown = seconds;
     if(this.intervalid){
      clearInterval(this.intervalid);}
      this.intervalid = setInterval(()=>{
        if(this.countdown>0){
          this.countdown--;
        }else{
          clearInterval(this.intervalid);
        }
      },1000);
     }
  }

