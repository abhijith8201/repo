import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-temperature-converter',
  templateUrl: './temperature-converter.component.html',
  styleUrls: ['./temperature-converter.component.css']
})
export class TemperatureConverterComponent implements OnInit {

  inputValue:number = 0;
  fromUnit:string='';
  toUnit:string = '';
  result:number |null= null;
  constructor() { }

  ngOnInit(): void {
  }
  convertTemperature(){
    if(!this.fromUnit || !this.toUnit || this.fromUnit === this.toUnit){
      this.result = undefined;
      return;
    }
    if(this.fromUnit == 'Celsius' && this.toUnit == 'Fahrenheit'){
      this.result = (this.inputValue * 9 / 5)+32;
    }else if(this.fromUnit == 'Fahrenheit' && this.toUnit == 'Celsius'){
      this.result = (this.inputValue - 32)* 5 / 9;
    } 
  }
}
