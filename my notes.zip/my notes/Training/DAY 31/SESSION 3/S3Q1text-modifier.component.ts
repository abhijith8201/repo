import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-text-modifier',
  templateUrl: './text-modifier.component.html',
  styleUrls: ['./text-modifier.component.css']
})
export class TextModifierComponent implements OnInit {
  originalText:string ='';
  modifiedText:string ='';
  constructor() { }

  ngOnInit(): void {
  }

  applyUppercase(){
    this.modifiedText = this.originalText.toUpperCase();
  }
  applyLowercase(){
    this.modifiedText = this.originalText.toLowerCase();
  }
    applyReverse(){
      this.modifiedText = reversestr(this.originalText);
  }
  clearText(){
    this.originalText = '';
    this.modifiedText = '';
  }
}
function reversestr(str:string):string{
  return str.split('').reverse().join('');
}