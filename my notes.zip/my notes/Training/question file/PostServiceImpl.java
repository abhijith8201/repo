package com.examly.springapp.service;

import com.examly.springapp.model.Post;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.PostRepository;
import com.examly.springapp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostServiceImpl implements PostService {

    @Autowired
    private PostRepository postRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public Post savePost(Post post, int userId) {
        User user = userRepository.findById(userId).orElse(null);
        if (user != null) {
            post.setUser(user);
            return postRepository.save(post);
        }
        return null;
    }

    @Override
    public Post getPostById(int postId) {
        return postRepository.findById(postId).orElse(null);
    }

    @Override
    public List<Post> getAllPosts() {
        return postRepository.findAll();
    }

    @Override
    public Post updatePost(int postId, Post post) {
        Post existingPost = postRepository.findById(postId).orElse(null);
        if (existingPost != null) {
            existingPost.setTitle(post.getTitle());
            existingPost.setContent(post.getContent());
            return postRepository.save(existingPost);
        }
        return null;
    }

    @Override
    public String deletePost(int postId) {
        Post post = postRepository.findById(postId).orElse(null);
        if (post != null) {
            postRepository.delete(post);
            return "Post deleted successfully";
        }
        return "Post not found with ID: " + postId;
    }
}
