package com.examly.springapp.service;

import com.examly.springapp.model.Post;
import java.util.List;

public interface PostService {
    Post savePost(Post post, int userId);
    Post getPostById(int postId);
    List<Post> getAllPosts();
    Post updatePost(int postId, Post post);
    String deletePost(int postId);
}
