import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {
  books:Book[] = [];
  newBookTitle:string="";
  constructor() { }

  ngOnInit(): void {
  }
  addBook(){
    if(this.newBookTitle){
      let book:Book={
        title:this.newBookTitle,completed:false
      }
      this.books.push(book);
      this.newBookTitle="";
    }
  }
  completeBook(book:Book){
     let index = this.books.indexOf(book);
     this.books[index].completed = !this.books[index].completed;
  }

  deleteBook(index:number){
    this.books.splice(index,1);
  }

}
export interface Book{
  title:string;
  completed:boolean;
}