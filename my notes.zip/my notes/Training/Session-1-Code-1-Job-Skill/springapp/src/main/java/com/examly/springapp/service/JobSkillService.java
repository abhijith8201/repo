package com.examly.springapp.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Job;
import com.examly.springapp.model.Skill;
import com.examly.springapp.repository.JobRepository;
import com.examly.springapp.repository.SkillsRepository;

@Service
public class JobSkillService {
    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private SkillsRepository skillsRepository;

    public Job addJobs(Job job){
        return jobRepository.save(job);
    }

    public Skill addSkill(Skill skill){
        return skillsRepository.save(skill);
    }

    public List<Job> getAllJob(){
        return jobRepository.findAll();
    }

    public List<Skill> getAllSkill(){
        return skillsRepository.findAll();
    }

    public Job getJobBySkill(Long jobId,Long skillId){
        Job job=jobRepository.findById(jobId).orElse(null);
        Skill skill=skillsRepository.findById(skillId).orElse(null);
        if(job==null || skill==null){
            return null;
        }
        else{
            job.getSkills().add(skill);
            job=jobRepository.save(job);
            skill.getJobs().add(job);
            skill=skillsRepository.save(skill);
            return job;
        }

    }

	public boolean deleteByJobId(Long jobId) {
		Job job=jobRepository.findById(jobId).orElse(null);
        if(job==null){
            return false;
        }
        else{
            Set<Skill> skills=job.getSkills();
            for(Skill s: skills){
                s.getJobs().remove(job);
                skillsRepository.save(s);
            }
        }
        jobRepository.delete(job);
        return true;

	}

}
