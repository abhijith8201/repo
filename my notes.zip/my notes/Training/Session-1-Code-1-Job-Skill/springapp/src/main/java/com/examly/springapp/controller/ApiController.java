package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Job;
import com.examly.springapp.model.Skill;
import com.examly.springapp.service.JobSkillService;

@RestController
@RequestMapping("/api")
public class ApiController {
    @Autowired
    private JobSkillService jobSkillService;

    @PostMapping("/jobs")
    public ResponseEntity<?> addJobs(@RequestBody Job job){
        job=jobSkillService.addJobs(job);
        return ResponseEntity.status(HttpStatus.CREATED).body(job);
    }

    @PostMapping("/skills")
    public ResponseEntity<?> addSkill(@RequestBody Skill skill){
        return ResponseEntity.status(HttpStatus.CREATED).body(jobSkillService.addSkill(skill));
    }

    @GetMapping("/jobs")
    public ResponseEntity<?> getAllJobs(){
        return ResponseEntity.status(HttpStatus.OK).body(jobSkillService.getAllJob());
    }

    @GetMapping("/skills")
    public ResponseEntity<?> getAllSkill(){
        return ResponseEntity.status(HttpStatus.OK).body(jobSkillService.getAllSkill());
    }

    @PostMapping("/jobs/{jobId}/add-skill/{skillId}")
    public ResponseEntity<?> getJobBySkill(@PathVariable Long jobId,@PathVariable Long skillId){
        return ResponseEntity.status(HttpStatus.CREATED).body(jobSkillService.getJobBySkill(jobId,skillId));
    }

    @DeleteMapping("/jobs/{id}")
    public ResponseEntity<?> deleteByJobId(@PathVariable Long id){
        boolean bool=jobSkillService.deleteByJobId(id);
        return ResponseEntity.status(HttpStatus.OK).body(bool);
    }
}
