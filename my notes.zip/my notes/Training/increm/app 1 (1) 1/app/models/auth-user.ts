export interface AuthUser {
    userId:number;
    userName:string;
    jwtToken:string;
    role:string;
    name:string;
}
