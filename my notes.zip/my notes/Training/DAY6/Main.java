// You are using Java
import java.util.*;
class Book{
    int sno;
    String title;
    String author;
    Book(int sno,String title,String author){
        this.sno = sno;
        this.title = title;
        this.author = author;}
    void display(){
        System.out.printf( "Serial No: "+sno+", Title: "+title+", Author: "+author+"");

    }
}
class BookManager {
    Book[] books;
    int count ;
    public BookManager(int size){
        books= new Book[size];
        count = 0;
    }
    
    public void addBook(Book book){
        if(count<books.length){
            books[count] = book;
            count++;
        }
        else{
            System.out.println("array full");
        }
    }
    public void displayDitails(){
        for(int i= 0;i<count;i++){
            books[i].display();
            System.out.println();
        }
    }
    
}
class main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        BookManager manager = new BookManager(num);
        for(int i=0;i<num;i++){
            int sno = sc.nextInt();
            sc.nextLine();
            String title = sc.nextLine();
            String author = sc.nextLine();
            Book book = new Book(sno,title,author);
            manager.addBook(book);
            
        }
         manager.displayDitails();
    }
}