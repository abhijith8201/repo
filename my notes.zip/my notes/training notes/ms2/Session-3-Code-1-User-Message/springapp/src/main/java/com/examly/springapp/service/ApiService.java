package com.examly.springapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Message;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.MessageRepo;
import com.examly.springapp.repository.UserRepo;

@Service
public class ApiService {
    @Autowired
    private UserRepo userRepo;

    @Autowired
    private MessageRepo messageRepo;


    public User addUser(User user){
        return userRepo.save(user);
    }

    public Message addMessageToUser(Message message,int id){
        User user = userRepo.findById(id).orElse(null);
        if(user==null){
            return null;
        }else{
            message.getUsers().add(user);
            message = messageRepo.save(message);
            user.getMessages().add(message);
            user = userRepo.save(user);
            return message;
        }
    }


    public List<User> findAllUsers(){
        return userRepo.findAll();
    }

    public User findById(int id){
        User existingUser = userRepo.findById(id).orElse(null);
        return existingUser;

    }

    /*public Message updateMassage(Message message,int msgId){
        Message existingMessage = messageRepo.findById(msgId).orElse(null);
        if(existingMessage==null){
            return null;
        }else{
            existingMessage.setName(message.getName());
            message = messageRepo.save(existingMessage);
            return message;

        }



    }*/


    
   


    
}
