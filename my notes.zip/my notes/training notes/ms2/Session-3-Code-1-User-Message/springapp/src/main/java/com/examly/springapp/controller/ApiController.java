package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Message;
import com.examly.springapp.model.User;
import com.examly.springapp.service.ApiService;

@RestController
public class ApiController {

    @Autowired
    private ApiService apiService;

    @PostMapping("/user")
    public ResponseEntity<?> addUser(@RequestBody User user){
        User existingUser = apiService.addUser(user);

        if(existingUser==null){
            return ResponseEntity.status(201).body("false");

        }else{
            return ResponseEntity.status(201).body("true");
        }

       


        
    }

    @PostMapping("/user/{id}/message")
    public ResponseEntity<?> addMessageToUser(@RequestBody Message message,@PathVariable int id){
        Message existingMessage = apiService.addMessageToUser(message, id);
       
        if(existingMessage==null){
            return ResponseEntity.status(500).body("false");

        }else{
            return ResponseEntity.status(201).body("true");
        }
        
    }

    @GetMapping("/user")
    public ResponseEntity<?> getAllUsers(){
        return ResponseEntity.status(200).body(apiService.findAllUsers());
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<?> getUserById(@PathVariable int id){
        User existingUser = apiService.findById(id);
        if(existingUser==null){
            return ResponseEntity.status(500).body("User Not found");
        }else{
            return ResponseEntity.status(200).body(existingUser);
        }
        
    }

    @PutMapping("/user/{userId}/message/{msgId}")
    public ResponseEntity<?> update(){
        return ResponseEntity.status(200).body("Test post");//apiService.updateMassage(message, msgId));
    }

    @DeleteMapping("/user/{userId}/message/{msgId}")
    public ResponseEntity<?> delete(){
        return ResponseEntity.status(200).body(true);
    } 





    
}
