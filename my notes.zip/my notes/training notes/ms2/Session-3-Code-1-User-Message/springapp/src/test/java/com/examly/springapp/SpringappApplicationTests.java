package com.examly.springapp;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.File;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@AutoConfigureMockMvc
class SpringappApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
        @Order(1)

    public void testCreateUser() throws Exception {
        String userJson = "{\"id\": 1, \"userName\": \"TestUser\"}";
        mockMvc.perform(MockMvcRequestBuilders.post("/user")
                .contentType(MediaType.APPLICATION_JSON)
                .content(userJson))
                .andExpect(status().isCreated());
    }

    @Test
        @Order(2)

    public void testSaveMessage() throws Exception {
        String postJson = "{\"id\": 1, \"name\": \"Test Post\"}";
        mockMvc.perform(MockMvcRequestBuilders.post("/user/1/message")
                .contentType(MediaType.APPLICATION_JSON)
                .content(postJson))
                .andExpect(status().isCreated());
    }

    @Test
        @Order(3)

    public void testGetAllUsers() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/user"))
                .andExpect(status().isOk());
    }

    @Test
        @Order(4)

    public void testGetPostsWithUserId() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/user/1"))
                .andExpect(status().isOk());
    }

    @Test
        @Order(5)

    public void testUpdateMessageName() throws Exception {
        String newText = "Updated text";
        mockMvc.perform(MockMvcRequestBuilders.put("/user/1/message/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("\"" + newText + "\""))
                .andExpect(status().isOk());
    }

    @Test
        @Order(6)
    public void testDeleteMessage() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/user/1/message/1"))
                .andExpect(status().isOk());
    }

	@Test
    public void testControllerFolder() {
        String directoryPath = "src/main/java/com/examly/springapp/controller";
        File directory = new File(directoryPath);
        assertTrue(directory.exists() && directory.isDirectory());
    }

    @Test
    public void testControllerFile() {
        String filePath = "src/main/java/com/examly/springapp/controller/ApiController.java";
        File file = new File(filePath);
        assertTrue(file.exists() && file.isFile());
    }

    @Test
    public void testModelFolder() {
        String directoryPath = "src/main/java/com/examly/springapp/model";
        File directory = new File(directoryPath);
        assertTrue(directory.exists() && directory.isDirectory());
    }

    @Test
    public void testModelFile() {
        String filePath = "src/main/java/com/examly/springapp/model/Message.java";
        File file = new File(filePath);
        assertTrue(file.exists() && file.isFile());
    }

    @Test
    public void testModelFile1() {
        String filePath = "src/main/java/com/examly/springapp/model/User.java";
        File file = new File(filePath);
        assertTrue(file.exists() && file.isFile());
    }

    @Test
    public void testRepositoryFolder() {
        String directoryPath = "src/main/java/com/examly/springapp/repository";
        File directory = new File(directoryPath);
        assertTrue(directory.exists() && directory.isDirectory());
    }

    @Test
    public void testRepositoryFile() {
        String filePath = "src/main/java/com/examly/springapp/repository/MessageRepo.java";
        File file = new File(filePath);
        assertTrue(file.exists() && file.isFile());
    }

    @Test
    public void testRepositoryFile1() {
        String filePath = "src/main/java/com/examly/springapp/repository/UserRepo.java";
        File file = new File(filePath);
        assertTrue(file.exists() && file.isFile());
    }

    @Test
    public void testServiceFolder() {
        String directoryPath = "src/main/java/com/examly/springapp/service";
        File directory = new File(directoryPath);
        assertTrue(directory.exists() && directory.isDirectory());
    }

    @Test
    public void testServiceFile() {
        String filePath = "src/main/java/com/examly/springapp/service/ApiService.java";
        File file = new File(filePath);
        assertTrue(file.exists() && file.isFile());
    }

}
