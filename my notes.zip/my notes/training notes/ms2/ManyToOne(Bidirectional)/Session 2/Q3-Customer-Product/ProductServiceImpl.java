package com.examly.springapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Customer;
import com.examly.springapp.model.Product;
import com.examly.springapp.repository.CustomerRepo;
import com.examly.springapp.repository.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductRepo pRepo;
    @Autowired 
    private CustomerRepo cRepo;

    @Override
    public Product assignCustomerToProduct(int customerId, Product product) {
        if(cRepo.existsById(customerId)){
            Customer customer = cRepo.findById(customerId).get();
            product.setCustomer(customer);
            return pRepo.save(product);
        }
         return null;
    }

    @Override
    public boolean deleteProduct(int productId) {
        if(pRepo.existsById(productId)){
            pRepo.deleteById(productId);
            return true;
        }
         return false;
    }

    
}
