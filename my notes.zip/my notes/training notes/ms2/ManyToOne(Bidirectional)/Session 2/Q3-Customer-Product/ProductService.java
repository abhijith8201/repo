package com.examly.springapp.service;

import com.examly.springapp.model.Product;

public interface ProductService {
    Product assignCustomerToProduct(int customerId,Product product);
    boolean deleteProduct(int productId);
    
}
