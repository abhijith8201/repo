package com.examly.springapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Customer;
import com.examly.springapp.repository.CustomerRepo;

@Service
public class CustomerServiceImpl implements CustomerService{
    @Autowired
    private CustomerRepo  cRepo;

    @Override
    public Customer createCustomer(Customer customer) {
        return cRepo.save(customer);
    }

    @Override
    public Customer getCustomerById(int customerId) {
        if(cRepo.existsById(customerId)){
            return cRepo.findById(customerId).get();
        }
        return null;
    }
}
