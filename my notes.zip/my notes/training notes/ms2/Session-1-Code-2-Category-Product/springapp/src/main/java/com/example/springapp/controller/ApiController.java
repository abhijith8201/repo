package com.example.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.springapp.model.Category;
import com.example.springapp.model.Product;
import com.example.springapp.service.ProductCategoryService;

@RestController
public class ApiController {
    
    @Autowired
    private ProductCategoryService productCategoryService;

    @PostMapping("/categories")
    public ResponseEntity<?> addcategory(@RequestBody Category categories){
         return ResponseEntity.status(HttpStatus.CREATED).body(productCategoryService.addCategory(categories));
    }

    @PostMapping("/categories/{categoriesId}/product")
    public ResponseEntity<?> addProductToCategoryId(@RequestBody Product product, @PathVariable Integer categoriesId){
         
        Product p = productCategoryService.addProductToCategory(product,categoriesId);
        if(p==null){
           return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("");
        }
        else{
            return ResponseEntity.status(HttpStatus.CREATED).body(p);
        }
    }

    @GetMapping("/categories/{categoryId}")
    public ResponseEntity<?> getCategoryById(@PathVariable Integer categoryId){
       
        Category c = productCategoryService.getCategoryById(categoryId);
        if(c==null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("");
        }
        else{
            return ResponseEntity.status(HttpStatus.OK).body(c);
        }
    }

    @DeleteMapping("/categories/product/{productId}")
    public ResponseEntity<?> deleteProductByProductId(@PathVariable Integer productId){
        
        return ResponseEntity.status(HttpStatus.OK).body(productCategoryService.deleteProductById(productId));
    }
}
