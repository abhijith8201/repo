package com.example.springapp.service;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springapp.model.Category;
import com.example.springapp.model.Product;
import com.example.springapp.repository.CategoryRepository;
import com.example.springapp.repository.ProductRepository;

@Service
public class ProductCategoryService {
    
    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    public Category addCategory(Category c){
       return categoryRepository.save(c);
    }

    public Category getCategoryById(Integer categoryId){
       return categoryRepository.findById(categoryId).orElse(null);
    }

    public Product addProductToCategory(Product product, Integer categoryId){
         Category c  = categoryRepository.findById(categoryId).orElse(null);
         if(c==null){
            return null;
         }
         else{
            product.getCategories().add(c);
            product = productRepository.save(product);
            c.getProducts().add(product);
            c = categoryRepository.save(c);
           
           
            return product;
         }
    }

    public boolean deleteProductById(Integer productId){
      
        Product product = productRepository.findById(productId).orElse(null);
        if(product==null){
            return false;
        }
        else{
            Set<Category> categories=product.getCategories();
            for(Category c:categories){
                c.getProducts().remove(product);
                categoryRepository.save(c);
            }
        }
       productRepository.delete(product);
        return true;
    }

   
}
