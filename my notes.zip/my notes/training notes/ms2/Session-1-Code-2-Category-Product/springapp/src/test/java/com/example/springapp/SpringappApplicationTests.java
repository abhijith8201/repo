package com.example.springapp;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.File;

@SpringBootTest
@AutoConfigureMockMvc
public class SpringappApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void testCreateCategory() throws Exception {
		String requestBody = "{\"name\": \"TestCategory\"}";
		mockMvc.perform(MockMvcRequestBuilders.post("/categories")
				.contentType(MediaType.APPLICATION_JSON)
				.content(requestBody)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}

	@Test
	public void testAddProductToCategory() throws Exception {
		String categoryRequestBody = "{\"name\": \"TestCategory\"}";
		String productRequestBody = "{\"name\": \"TestProduct\", \"price\": 10.0}";

		mockMvc.perform(MockMvcRequestBuilders.post("/categories")
				.contentType(MediaType.APPLICATION_JSON)
				.content(categoryRequestBody)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());

		mockMvc.perform(MockMvcRequestBuilders.post("/categories/1/product")
				.contentType(MediaType.APPLICATION_JSON)
				.content(productRequestBody)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}

	@Test
	public void testGetCategoryWithProducts() throws Exception {
		String categoryRequestBody = "{\"name\": \"TestCategory\"}";
		mockMvc.perform(MockMvcRequestBuilders.post("/categories")
				.contentType(MediaType.APPLICATION_JSON)
				.content(categoryRequestBody)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());

		mockMvc.perform(MockMvcRequestBuilders.get("/categories/1")
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	@Test
	public void testDeleteProduct() throws Exception {
		String categoryRequestBody = "{\"name\": \"TestCategory\"}";
		String productRequestBody = "{\"name\": \"TestProduct\", \"price\": 10.0}";

		mockMvc.perform(MockMvcRequestBuilders.post("/categories")
				.contentType(MediaType.APPLICATION_JSON)
				.content(categoryRequestBody)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());

		mockMvc.perform(MockMvcRequestBuilders.post("/categories/1/product")
				.contentType(MediaType.APPLICATION_JSON)
				.content(productRequestBody)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());

		mockMvc.perform(MockMvcRequestBuilders.delete("/categories/product/1")
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	@Test

	public void controllerfolder() {
		String directoryPath = "src/main/java/com/example/springapp/controller"; // Replace with the path to your
																					// directory
		File directory = new File(directoryPath);
		assertTrue(directory.exists() && directory.isDirectory());
	}

	@Test
	public void controllerfile() {
		String filePath = "src/main/java/com/example/springapp/controller/ApiController.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());
	}

	@Test
	public void testModelFolder() {
		String directoryPath = "src/main/java/com/example/springapp/model"; // Replace with the path to your directory
		File directory = new File(directoryPath);
		assertTrue(directory.exists() && directory.isDirectory());
	}

	@Test
	public void testModelFile() {
		String filePath = "src/main/java/com/example/springapp/model/Category.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());
	}

	@Test
	public void testModelFile2() {
		String filePath = "src/main/java/com/example/springapp/model/Product.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());
	}

	@Test
	public void testrepositoryfolder() {
		String directoryPath = "src/main/java/com/example/springapp/repository"; // Replace with the path to your
																					// directory
		File directory = new File(directoryPath);
		assertTrue(directory.exists() && directory.isDirectory());
	}

	@Test

	public void testrepositoryFile() {

		String filePath = "src/main/java/com/example/springapp/repository/CategoryRepository.java";
		// Replace with the path to your file
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());
	}

	@Test

	public void testrepositoryFile2() {

		String filePath = "src/main/java/com/example/springapp/repository/ProductRepository.java";
		// Replace with the path to your file
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());
	}

	@Test
	public void testServiceFolder() {
		String directoryPath = "src/main/java/com/example/springapp/service";
		File directory = new File(directoryPath);

		assertTrue(directory.exists() && directory.isDirectory());

	}

	@Test

	public void testServieFile() {

		String filePath = "src/main/java/com/example/springapp/service/ProductCategoryService.java";

		File file = new File(filePath);

		assertTrue(file.exists() && file.isFile());

	}
}
