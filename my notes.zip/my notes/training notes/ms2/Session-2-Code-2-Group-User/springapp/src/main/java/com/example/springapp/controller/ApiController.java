package com.example.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.springapp.model.Group;
import com.example.springapp.model.User;
import com.example.springapp.service.ApiService;

@RestController
@RequestMapping("/api")
public class ApiController {
    @Autowired
    private ApiService apiService;

    // Create a new Group
    @PostMapping("/groups")
    public Group createGroup(@RequestBody Group group) {
        return apiService.createGroup(group);
    }

    // Create a new User
    @PostMapping("/users")
    public User createUser(@RequestBody User user) {
        return apiService.createUser(user);
    }

    @PostMapping("/groups/{groupId}/addUser/{userId}")
    public ResponseEntity<User> addUserToGroup(@PathVariable Long groupId, @PathVariable Long userId) {
        User user = apiService.addUserToGroup(groupId, userId);

        if (user != null) {
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/users")
    public List<User> getAllUsers() {
        return apiService.getAllUsers();
    }

    @GetMapping("/groups/{groupId}")
    public Group getGroupWithUsers(@PathVariable Long groupId) {
        return apiService.getGroupWithUsers(groupId);
    }

}
