package com.example.springapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springapp.model.User;
import com.example.springapp.repository.GroupRepository;
import com.example.springapp.repository.UserRepository;
import com.example.springapp.model.Group;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jakarta.persistence.EntityGraph;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Service
public class ApiService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private GroupRepository groupRepository;

    @PersistenceContext
    private EntityManager entityManager;

    public User createUser(User user) {
        return userRepository.save(user);
    }

    public Group createGroup(Group group) {
        return groupRepository.save(group);
    }

    @Transactional
    public User addUserToGroup(Long groupId, Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        Group group = groupRepository.findById(groupId).orElse(null);

        if (user != null && group != null) {
            user.getGroups().add(group);
            userRepository.save(user);
        }

        return user;
    }

    public Set<User> getUsersInGroup(Long groupId) {
        Group group = groupRepository.findById(groupId).orElse(null);
        return group != null ? group.getUsers() : null;
    }

    public Set<Group> getGroupsForUser(Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        return user != null ? user.getGroups() : null;
    }

    // In ApiService.java
    public Group getGroupWithUsers(Long groupId) {
        EntityGraph<Group> graph = entityManager.createEntityGraph(Group.class);
        graph.addSubgraph("users"); // Load the "users" collection eagerly

        Map<String, Object> hints = new HashMap<>();
        hints.put("jakarta.persistence.fetchgraph", graph);

        return entityManager.find(Group.class, groupId, hints);
    }

    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }

    @Transactional
    public void deleteGroup(Long groupId) {
        Group group = groupRepository.findById(groupId).orElse(null);

        if (group != null) {
            // Remove the group from the users
            for (User user : group.getUsers()) {
                user.getGroups().remove(group);
            }
            group.getUsers().clear();
            groupRepository.delete(group);
        }
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

}
