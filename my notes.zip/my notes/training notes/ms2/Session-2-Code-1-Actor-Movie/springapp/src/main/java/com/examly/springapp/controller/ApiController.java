package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Actor;
import com.examly.springapp.model.Movie;
import com.examly.springapp.service.MovieService;

@RestController
public class ApiController {

    @Autowired
    private MovieService movieService;

    @PostMapping("/addmovie")
    public ResponseEntity<?> addMovie(@RequestBody Movie movie){
        return ResponseEntity.status(HttpStatus.CREATED).body(movieService.addMovie(movie));
    }

    @PostMapping("/addactor")
    public ResponseEntity<?> addActor(@RequestBody Actor actor){
        return ResponseEntity.status(HttpStatus.CREATED).body(movieService.addActor(actor));
    }

    @PostMapping("/movies/{movieId}/actors/{actorId}")
    public ResponseEntity<?> addMoviesToActors(@PathVariable int movieId,@PathVariable int actorId){
        return ResponseEntity.status(HttpStatus.CREATED).body(movieService.addMoviesToActors(movieId,actorId));
    }

    @GetMapping("/movies")
    public ResponseEntity<?> getMovies(){
        return ResponseEntity.status(HttpStatus.OK).body(movieService.getMovies());
    }

    @GetMapping("/actors/{actorId}")
    public ResponseEntity<?> getActorById(@PathVariable int actorId){
        return ResponseEntity.status(HttpStatus.OK).body(movieService.getActorById(actorId));
    }

    @PutMapping("/updateactor/{actorId}")
    public ResponseEntity<?> updateActorById(){
        return ResponseEntity.status(HttpStatus.OK).body(null);
    }

    @PutMapping("/updatemovie/{movieId}")
    public ResponseEntity<?> updateMovieById(){
        return ResponseEntity.status(HttpStatus.OK).body(null);
    }
    
}
