package com.examly.springapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Actor;
import com.examly.springapp.model.Movie;
import com.examly.springapp.repository.ActorRepository;
import com.examly.springapp.repository.MovieRepository;

@Service
public class MovieService {

    @Autowired
    private MovieRepository movieRepository;
    @Autowired
    private ActorRepository actorRepository;

	public Movie addMovie(Movie movie) {
        return movieRepository.save(movie);
    }
	public Actor addActor(Actor actor) {
        return actorRepository.save(actor);
    }
    public boolean addMoviesToActors(int movieId, int actorId) {
        
        Movie movie=movieRepository.findById(movieId).orElse(null);
        Actor actor=actorRepository.findById(actorId).orElse(null);
        actor.getMovies().add(movie);
        movie.getActors().add(actor);
        return true;
    }
    public List<Movie> getMovies() {
        return movieRepository.findAll();
    }
	public Actor getActorById(int actorId) {
		
        return actorRepository.findById(actorId).orElse(null);
    }

    
		
    
}
