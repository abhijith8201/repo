package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Playlist;
import com.examly.springapp.model.Song;
import com.examly.springapp.service.ApiService;

@RestController
public class ApiController {

    @Autowired
    private ApiService apiService;

    @PostMapping("/addplaylist")
    public ResponseEntity<?> addPlaylist(@RequestBody Playlist addplaylist){
        apiService.addPlaylist(addplaylist);
        return ResponseEntity.status(201).body(true);
    }
    @PostMapping("/addsong")
    public ResponseEntity<?> addSong(@RequestBody Song addsong){
        apiService.addSong(addsong);
        return ResponseEntity.status(201).body(true);
        
    }

    @PostMapping("/playlists/{playlistId}/addSong/{songId}")
    public ResponseEntity<?> addSongToPlaylist(@PathVariable int songId,@PathVariable int playlistId){
        apiService.addSongToPlaylist(songId, playlistId);
        return ResponseEntity.status(201).body(true);
    }

    @GetMapping("/playlists")
    public ResponseEntity<?> getAllPlaylists(){
        
        return ResponseEntity.status(200).body(apiService.findAllPlaylist());
    }

    @GetMapping("/songs")
    public ResponseEntity<?> getAllSongs(){
        return ResponseEntity.status(200).body(apiService.findAllSongs());
    }

    
}
