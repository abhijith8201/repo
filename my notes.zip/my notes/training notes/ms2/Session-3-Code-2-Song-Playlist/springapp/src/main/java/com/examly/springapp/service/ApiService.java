package com.examly.springapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Playlist;
import com.examly.springapp.model.Song;
import com.examly.springapp.repository.PlaylistRepo;
import com.examly.springapp.repository.SongRepo;

@Service
public class ApiService {

    @Autowired
    private PlaylistRepo playlistRepo;

    @Autowired
    private SongRepo songRepo;

    public Playlist addPlaylist(Playlist playlist){
        return playlistRepo.save(playlist);
    }

    public Song addSong(Song song){
        return songRepo.save(song);
    }

    public Song addSongToPlaylist(int songId,int playlistId){
        Playlist playlist = playlistRepo.findById(playlistId).orElse(null);

        Song song = songRepo.findById(songId).orElse(null);

        if(playlist==null || song==null){
            return null;
        }else{
            song.getPlaylists().add(playlist);
            song = songRepo.save(song);
            playlist.getSongs().add(song);
            playlist=playlistRepo.save(playlist);
            return song;


        }

    }

    public List<Playlist> findAllPlaylist(){
        return playlistRepo.findAll();
        
    }

    public List<Song> findAllSongs(){
        return songRepo.findAll();
    }

    
}
