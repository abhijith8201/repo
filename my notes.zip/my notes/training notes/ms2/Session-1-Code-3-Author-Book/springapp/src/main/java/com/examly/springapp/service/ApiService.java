package com.examly.springapp.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Author;
import com.examly.springapp.model.Book;
import com.examly.springapp.repository.AuthorRepo;
import com.examly.springapp.repository.BookRepo;

import jakarta.persistence.EntityNotFoundException;


@Service
public class ApiService {
    
    @Autowired
    private AuthorRepo authorRepo;

    @Autowired
    private BookRepo bookRepo;

    public Author addAuthor(Author author) {
        return authorRepo.save(author);
    }

    public Book addBook(Book book, int authorId){
        Author author = authorRepo.findById(authorId).orElse(null);
        if(author == null){
            throw new EntityNotFoundException("Author not exist");
        }
        book.getAuthor().add(author);
        book = bookRepo.save(book);
        author.getBooks().add(book);
        authorRepo.save(author);
        return book;
    }

    public List<Author> getAuthors(){
        return authorRepo.findAll();
    }

    public Author getAuthorById(int authorId){
        return authorRepo.findById(authorId).orElse(null);
    }

    public Book updateBook(Book book,int authorId, int bookId){
        System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
        System.out.println("Book : "+book+" Author ID : "+authorId+" Book ID : "+bookId);
        System.out.println("Searching book ...............................");
        Book existingBook = bookRepo.findById(bookId).orElse(null);
        System.out.println("===============================================");
        System.out.println(existingBook);
        System.out.println("===============================================");
        if(existingBook == null)
            return null;
        else{
            existingBook.setTitle(book.getTitle());
            book = bookRepo.save(existingBook);
            return book;
        }
    }

}
