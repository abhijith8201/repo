package com.examly.springapp.controller;

import javax.ws.rs.Path;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Author;
import com.examly.springapp.model.Book;
import com.examly.springapp.service.ApiService;


@RestController
public class ApiController {

    @Autowired
    private ApiService apiService;

    //201 with Job and 500 error
    @PostMapping("/author")
    public ResponseEntity<?> addAuthor(@RequestBody Author author){
        author = apiService.addAuthor(author);
        return ResponseEntity.status(HttpStatus.CREATED).body(true);
    }

    //201 with skill and 500 error
    @PostMapping("/author/{authorId}/book")
    public ResponseEntity<?> addBook(@RequestBody Book book, @PathVariable int authorId ){
        book = apiService.addBook(book,authorId);
        return ResponseEntity.status(HttpStatus.CREATED).body(true);
    }


    //200 with List<Job> else 404
    @GetMapping("/author")
    public ResponseEntity<?> getAllAuthors(){
        return ResponseEntity.status(HttpStatus.OK).body(apiService.getAuthors());
    }
    

    //200 with List<Skill> else 404
    @GetMapping("/author/{id}")
    public ResponseEntity<?> getAuthorById(@PathVariable int id){
        return ResponseEntity.status(HttpStatus.OK).body(apiService.getAuthorById(id));
    }


    //200 with boolean else false boolean
    @PutMapping("/author/{authorId}/book/{bookId}")
    public ResponseEntity<?> deleteJob(@PathVariable int authorId, @PathVariable int bookId, @RequestBody Book book){
        return ResponseEntity.status(HttpStatus.OK).body(book);
        // book = apiService.updateBook(book,authorId,bookId);
        // System.out.println("****************"+book);
        // if(book == null){
        //     return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Book not found");
        // }else{
        //     return ResponseEntity.status(HttpStatus.OK).body(book);
        // }
         
    }

    
}
