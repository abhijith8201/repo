package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Doctor;
import com.examly.springapp.model.Patients;
import com.examly.springapp.service.ApiService;

@RestController
public class ApiController {

    @Autowired
    private ApiService apiService;

    @PostMapping("/api/doctors")
    public ResponseEntity<?>addDoctor(@RequestBody Doctor doctor){
        return ResponseEntity.status(HttpStatus.CREATED).body(apiService.addDoctor(doctor));
    }

    @PostMapping("/api/patients")
    public ResponseEntity<?>addPatients(@RequestBody Patients patients){
        return ResponseEntity.status(HttpStatus.CREATED).body(apiService.addPatients(patients));
    }

    @PostMapping("/api/doctors/{doctorId}/add-patient/{patientId}")
    public ResponseEntity<?>addPatientsToDoctor(@PathVariable Long patientId,@PathVariable Long doctorId){
       Doctor doctor=apiService.addPatientsToDoctor(patientId, doctorId);
        return ResponseEntity.status(HttpStatus.CREATED).body(doctor);
    }

    @GetMapping("/api/doctors")
    public ResponseEntity<?>getAllDoctors(){
        return ResponseEntity.status(HttpStatus.OK).body(apiService.getAllDoctors());
    }

    @GetMapping("/api/patients")
    public ResponseEntity<?>getAllPatients(){
        return ResponseEntity.status(HttpStatus.OK).body(apiService.getAllPatients());
    }

    @DeleteMapping("/api/doctors/{id}")
    public ResponseEntity<?>delete(@PathVariable Long id){
        boolean bool = apiService.delete(id);
        if(bool){
            return ResponseEntity.status(HttpStatus.OK).body(bool);
        }else{
            return ResponseEntity.status(HttpStatus.OK).body(bool);
        }
    }
    
}
