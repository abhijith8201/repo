package com.examly.springapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Doctor;
import com.examly.springapp.model.Patients;
import com.examly.springapp.repository.DoctorRepository;
import com.examly.springapp.repository.PatientRepository;
import java.util.List;
import java.util.Set;

@Service
public class ApiService {

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private PatientRepository patientRepository;


    public Doctor addDoctor(Doctor doctor){
        return doctorRepository.save(doctor);
    }

    public Patients addPatients(Patients patients){
        return patientRepository.save(patients);
    }

    public Doctor addPatientsToDoctor(Long patientsId,Long doctorId){
        Doctor doctor = doctorRepository.findById(doctorId).orElse(null);

        Patients patients = patientRepository.findById(patientsId).orElse(null);

        if(doctor==null || patients==null){
            return null;
        }else{
            patients.getDoctors().add(doctor);
            patients = patientRepository.save(patients);
            doctor.getPatients().add(patients);
            doctor=doctorRepository.save(doctor);
            return doctor;


        }
    }

    public List<Doctor>getAllDoctors(){
        return doctorRepository.findAll();
    }

    public List<Patients>getAllPatients(){
        return patientRepository.findAll();
    }

    public boolean delete(Long doctorId){
        Doctor doctor=doctorRepository.findById(doctorId).orElse(null);
        if(doctor==null){
            return false;
        }else{
            Set<Patients> patients=doctor.getPatients();
            for(Patients p:patients){
                p.getDoctors().remove(doctor);
                patientRepository.save(p);
            }
        }
        doctorRepository.delete(doctor);
        return true;
    }
    
}
