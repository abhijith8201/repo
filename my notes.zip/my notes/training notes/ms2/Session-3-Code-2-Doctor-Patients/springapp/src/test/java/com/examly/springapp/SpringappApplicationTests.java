package com.examly.springapp;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.File;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class SpringappApplicationTests {
	@Autowired
	private MockMvc mockMvc;

	@Test
	public void testCreateDoctor() throws Exception {
		String requestBody = "{ \"id\":1,\"title\": \"Full Stack Developer\", \"description\": \"Full Stack Developer Description\" }";

		mockMvc.perform(MockMvcRequestBuilders.post("/api/doctors")
				.contentType(MediaType.APPLICATION_JSON)
				.content(requestBody)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated())
				.andReturn();
	}

	@Test
	public void testCreatePatient() throws Exception {
		String requestBody = "{\"id\":1,\"name\": \"Java\" }";

		mockMvc.perform(MockMvcRequestBuilders.post("/api/patients")
				.contentType(MediaType.APPLICATION_JSON)
				.content(requestBody)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated())
				.andReturn();
	}

	@Test
	public void testAddPatientToDoctor() throws Exception {
		// Create a doctor and a patient first
		testCreateDoctor();
		testCreatePatient();

		mockMvc.perform(MockMvcRequestBuilders.post("/api/doctors/1/add-patient/1")
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}

	@Test
	public void testRemoveDoctors() throws Exception {
		// Create a doctor, a patient, and add the patient to the doctor
		testCreateDoctor();
		testCreatePatient();
		testAddPatientToDoctor();

		mockMvc.perform(MockMvcRequestBuilders.delete("/api/doctors/1")
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	@Test
	public void testGetAllDoctors() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/api/doctors")
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
	}

	@Test
	public void testGetAllPatients() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/api/patients")
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
	}

	@Test
	public void testControllerFolder() {
		String directoryPath = "src/main/java/com/examly/springapp/controller";
		File directory = new File(directoryPath);
		assertTrue(directory.exists() && directory.isDirectory());
	}

	@Test
	public void testControllerFile() {
		String filePath = "src/main/java/com/examly/springapp/controller/ApiController.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());
	}

	@Test
	public void testModelFolder() {
		String directoryPath = "src/main/java/com/examly/springapp/model";
		File directory = new File(directoryPath);
		assertTrue(directory.exists() && directory.isDirectory());
	}

	@Test
	public void testModelFile() {
		String filePath = "src/main/java/com/examly/springapp/model/Doctor.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());
	}

	@Test
	public void testRepositoryFolder() {
		String directoryPath = "src/main/java/com/examly/springapp/repository";
		File directory = new File(directoryPath);
		assertTrue(directory.exists() && directory.isDirectory());
	}

	@Test
	public void testRepositoryFile() {
		String filePath = "src/main/java/com/examly/springapp/repository/DoctorRepository.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());
	}

	@Test
	public void testServiceFolder() {
		String directoryPath = "src/main/java/com/examly/springapp/service";
		File directory = new File(directoryPath);
		assertTrue(directory.exists() && directory.isDirectory());
	}

	@Test
	public void testServiceFile() {
		String filePath = "src/main/java/com/examly/springapp/service/ApiService.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());
	}
}
