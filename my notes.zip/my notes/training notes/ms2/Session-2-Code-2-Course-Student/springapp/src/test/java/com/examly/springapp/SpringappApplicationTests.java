package com.examly.springapp;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import java.io.File;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SpringappApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Test
	@Order(1)
	public void testAddStudentWithCourses() throws Exception {
		String requestBody = "{ \"id\": 1, \"name\": \"Test Student\", \"courses\": [] }";

		mockMvc.perform(MockMvcRequestBuilders.post("/addstudent")
				.contentType(MediaType.APPLICATION_JSON)
				.content(requestBody)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated())
				.andReturn();
	}

	@Test
	@Order(2)
	public void testGetAllStudents() throws Exception {
		// Implement this test to get all students and check the response.
		mockMvc.perform(MockMvcRequestBuilders.get("/getallstudent")
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
	}

	@Test
	@Order(3)
	public void testFindStudent() throws Exception {
		// Implement this test to find a specific student and check the response.
		mockMvc.perform(MockMvcRequestBuilders.get("/student/1")
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
	}

	@Test
	@Order(4)
	public void testUpdateStudent() throws Exception {
		// Implement this test to update a student and check the response.
		String requestBody = "{ \"name\": \"Updated Student\", \"courses\": [] }";

		mockMvc.perform(MockMvcRequestBuilders.put("/updatestudent/1")
				.contentType(MediaType.APPLICATION_JSON)
				.content(requestBody)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
	}

	@Test
	@Order(5)
	public void testUpdateCourse() throws Exception {
		String requestBody = "{ \"name\": \"Updated Course\" }";

		mockMvc.perform(MockMvcRequestBuilders.put("/updatecourse/1")
				.contentType(MediaType.APPLICATION_JSON)
				.content(requestBody)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andReturn();
	}

	@Test
	public void testControllerFolder() {
		// Implement this test to check the existence of the controller folder.
		String directoryPath = "src/main/java/com/examly/springapp/controller";
		File directory = new File(directoryPath);
		assertTrue(directory.exists() && directory.isDirectory());
	}

	@Test
	public void testControllerFile() {
		// Implement this test to check the existence of the controller file.
		String filePath = "src/main/java/com/examly/springapp/controller/ApiController.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());
	}

	@Test
	public void testModelFolder() {
		// Implement this test to check the existence of the model folder.
		String directoryPath = "src/main/java/com/examly/springapp/model";
		File directory = new File(directoryPath);
		assertTrue(directory.exists() && directory.isDirectory());
	}

	@Test
	public void testModelFile() {
		// Implement this test to check the existence of the model file.
		String filePath = "src/main/java/com/examly/springapp/model/Student.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());
	}

	@Test
	public void testRepositoryFolder() {
		// Implement this test to check the existence of the repository folder.
		String directoryPath = "src/main/java/com/examly/springapp/repository";
		File directory = new File(directoryPath);
		assertTrue(directory.exists() && directory.isDirectory());
	}

	@Test
	public void testRepositoryFile() {
		// Implement this test to check the existence of the repository file.
		String filePath = "src/main/java/com/examly/springapp/repository/StudentRepo.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());
	}

	@Test
	public void testServiceFolder() {
		// Implement this test to check the existence of the service folder.
		String directoryPath = "src/main/java/com/examly/springapp/service";
		File directory = new File(directoryPath);
		assertTrue(directory.exists() && directory.isDirectory());
	}

	@Test
	public void testServiceFile() {
		// Implement this test to check the existence of the service file.
		String filePath = "src/main/java/com/examly/springapp/service/ApiService.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());
	}
}
