package com.examly.springapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Course;
import com.examly.springapp.model.Student;
import com.examly.springapp.repository.CourseRepo;
import com.examly.springapp.repository.StudentRepo;

@Service
public class ApiService {
    
    @Autowired
    private CourseRepo courseRepo;

    @Autowired
    private StudentRepo studentRepo;

    public Student addStudent(Student student){
        return studentRepo.save(student);
    }

    public List<Student> getAllStudents(){
        return studentRepo.findAll();
    }

    public Student getStudentById(int id){
        return studentRepo.findById(id).orElse(null);
    }

    public Course updateCourseById(Course course, int id){
        
        Course eCourse=courseRepo.findById(id).orElse(null);

        if(eCourse==null){
            return null;
        }else{
            eCourse.setName(course.getName());
            eCourse=courseRepo.save(eCourse);

            return eCourse;
        }
    }

    public Student updateStudentById(Student student, int id){
        
        Student eStudent=studentRepo.findById(id).orElse(null);

        if(eStudent==null){
            return null;
        }else{
            eStudent.setName(student.getName());
            eStudent=studentRepo.save(eStudent);

            return eStudent;
        }
    }
}
