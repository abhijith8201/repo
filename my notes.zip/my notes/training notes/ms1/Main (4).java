// You are using Java
import java.util.*;
class Appliance implements Comparable<Appliance>{
    private int id ;
    private String name;
    private boolean rented ;
    
    Appliance(String name,int id){
        this.name = name;
        this.id = id;
        this.rented = false;
    }
    public String getName(){
        return name;
    }
    public int getId(){
        return id;
    }
    public boolean getRented(){
        return rented;
    }
    public void setId(int id){
        this.id = id;
    }
    public void setRented(boolean rented){
        this.rented = rented;
    }
    public int compareTo(Appliance e){
        return this.id-e.id;
    }
    public String toString(){
        return "Appliance{id ="+id+", name='"+name+"',rented="+rented+"} \n";
    }
    
}
class ItemException extends Exception{
    ItemException(String msg){
    super(msg);}
}

class Store{
     ArrayList<Appliance> a;
     
     Store(){
         a = new ArrayList<>();
     }
     public int coundId = 301;
         void addAppliance(String name){
             
                 
                 a.add(new Appliance(name,coundId));
                 coundId = coundId+1;
                 
            }
public void tobeRented(int id){
    try{
         
        boolean found = false;
        for(Appliance a:a){
            if(a.getId()==id){
            a.setRented(true);
            found = true;
            break;
        }
         
        }if (!found) {
                throw new ItemException("Appliance with ID " + id + " not found.");
        
    }}catch(ItemException r){
        System.out.println("to be deleted item not found");
    }
    
}
public void nrcount(){
    
         
       int c=0;
        for(Appliance a:a){
            if(!a.getRented()){
           c++;
        }else continue;
        }
        System.out.println(c);
    
         
    
}
void displayAll() {
    Collections.sort( a);
    for (Appliance a : a) {
        System.out.println(a);
    }
}

}

class main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Store s = new Store();
        sc.nextLine();
        for(int i=0;i<n;i++){
            String item = sc.nextLine();
            s.addAppliance(item);
        }
        int id1 = sc.nextInt();
        
        s.tobeRented(id1);
        s.tobeRented(302);
        s.nrcount();
        s.displayAll();
    }
}