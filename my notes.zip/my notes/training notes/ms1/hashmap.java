// You are using Java
import java.util.*;
class task{
    private String name ;
    private int priority ;
    task(String name,int priority){
        this.name=name;
        this.priority = priority;
    }
    public String getname(){
        return name;
    }
    public String toString(){
        return name+" "+priority;
    }
}
class priorityComparator implements Comparator<task>{
   public int compare(task e1,task e2){
       return e1.getname().compareTo(e2.getname());
   }
}
class main{
    public static void main(String[] args){
       Scanner sc = new Scanner(System.in);    // 1)  Create ArrayList 
       HashMap<Integer,task> mp = new HashMap<>();
       while(sc.hasNext()){                                 // 2. Scann the records
            String s = sc.nextLine();
           if(!s.equals("Completed")){
               
              String[] arr = s.split(" ");
              int id = Integer.parseInt(arr[0]);
              String name = arr[1];
              int priority = Integer.parseInt(arr[2]);
              mp.put(id,new task(name,priority));
           }
       }
       ArrayList<task> al = new ArrayList<>(mp.values());
        Collections.sort(al,new priorityComparator());
        for(task s: al){
             System.out.println(s);}
         
    }
}