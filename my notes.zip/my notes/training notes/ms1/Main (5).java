
import java.util.*;
class Book{
    private int serialNumber;
    private String title;
    private String author;
    private int decade;
    Book(int serialNumber,String title,String author,int decade){
        this.serialNumber = serialNumber;
        this.title = title;
        this.author = author;
        this.decade = decade;
    }
    public int getSerialNumber(){
        return serialNumber;
    }
    public int getDecade(){
        return decade;
    }
    public String toString(){
        return "BookIyem Serial Number:"+serialNumber+
        "\nTitle:"+title+
        "\nAuthor:"+author+
        "\nDecade:"+decade;
    }
}
class Store{
    ArrayList<Book> a;
    Store(){
        a=new ArrayList<>();
    }
    public void addBook(int serialNumber,String title,String author,int decade){
        a.add(new Book(serialNumber,title,author,decade));
    }
    public void retriveBookitem(int serialNumber){
        boolean found = false;
        for(Book a:a){
            if(a.getSerialNumber()==serialNumber){
                System.out.println("Book with serial Number "+serialNumber);
                System.out.println(a);
                found = true;
                break;
            }
            if(!found){
                System.out.println("Book Item with Serial Number does not exist");
            }
        }

    }
    public void bookByDecade(int decade){
      boolean found = false; 
        for(Book a:a){
            
            if(a.getDecade()==decade){
                found = true;
                System.out.println("  Book from the decade in stock");
            }
            
        }
        if(!found){
                System.out.println("No Book from the decade in stock");

            }
    }
    public void displayAll(){
        for(Book a:a){
            System.out.println(a);
        }
    }
    public void sum(int year){
        int sum = 0;
        for(Book a:a){
            if(a.getDecade()==year){
                sum=sum+1;
                continue;
            }
        }
        System.out.println(sum);
    }
}
class main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        Store s = new Store();
        int n = sc.nextInt();
        for(int i = 0;i<n;i++){
            int id = sc.nextInt();
            sc.nextLine();
            String title  = sc.nextLine();
            String author = sc.nextLine();
            int decade = sc.nextInt();
            
            s.addBook(id,title,author,decade);
            
        }
         int retrive = sc.nextInt();
         int decade = sc.nextInt();
         s.displayAll();
        s.retriveBookitem(retrive);
        s.bookByDecade(decade);
        s.sum(1960);
    }
}