// You are using Java
import java.util.*;

class Task implements Comparable<Task>{
     private String name;
     private int priority;
     Task(String name,int priority){
         this.name = name;
         this.priority = priority;
     }
     public String toString(){
         return "Task: "+name+", Priority: "+priority; 
     }
     public int compareTo(Task t){
         if(this.priority-t.priority == 0){
             return this.name.compareTo(t.name);
             
         }
         else{
             return this.priority - t.priority;
         }
     }
    }
    

class main{
    public static void main(String[] args){
        
        ArrayList<Task> list = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        while(sc.hasNext()){
            String name = sc.next();
            if(name.equalsIgnoreCase("Done"))
            break;
            int priority = sc.nextInt();
            Task t = new Task(name,priority);
            list.add(t);
        }
        Collections.sort(list);
        System.out.println(list);
    }
}