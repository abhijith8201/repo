// You are using Javaimport
import java.util.*;
class Ticket implements Comparable<Ticket>{
    private int ticket;
    private String problem;
    private int hours;
    
    Ticket(int ticket,String problem,int hours){
        this.ticket = ticket;
        this.problem = problem;
        this.hours = hours;
    }
    public int getHours(){
        return hours;
    }
    public int compareTo(Ticket e){
        return  e.hours-this.hours;
    }
    public String toString(){
        return "Ticket ID:"+ticket+
        "\nProblem Description:"+problem+
        "\nHours Spend:"+hours;
    }
    
}
class ItemException extends Exception{
    ItemException(String msg){
        super(msg);
    }
}
class Store {
    
    ArrayList<Ticket> a;
    Store(){
        a = new ArrayList<>();
    }
    
        public void addTicket(int ticket,String problem,int hours){
            try{
            if(ticket<0){
                throw new NumberFormatException("Please enter a valid integer");
            }
            if(ticket==0 || ticket >10){
                throw new ItemException("Ticket must be a positive integer between 1 and 100.");
            }
            if(ticket>0 && ticket<11){
                a.add(new Ticket(ticket,problem,hours));
            }
            
        }catch(ItemException e){
        System.out.println(e.getMessage());
    }catch(NumberFormatException e2){
        System.out.println(e2.getMessage());
    }
    
    }
    public void displayAll(){
        Collections.sort(a);
        for(Ticket a:a){
            System.out.println(a);
        }
    }
    public void avaragehours(){
        double sum = 0.0;
        int count = 0;
        for(Ticket a:a){
            sum = a.getHours()+sum;
            count++;
        }
        double avghours = sum/count;
        System.out.println(avghours);
    }
    
}
class main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        Store s = new Store();
        int id = 0;
        while(sc.hasNext()){
            String num = sc.nextLine();
            if(num.equals("Stop")){
                
                break;
            }
             id = Integer.parseInt(num);
            String prob = sc.nextLine();
            int time = sc.nextInt();
            s.addTicket(id,prob,time);
            sc.nextLine();
        }
        if(id>0 && id<11){
            s.displayAll();
        }
        s.avaragehours();
         
    }
}