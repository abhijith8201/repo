// You are using Java
import java.util.*;
class task{
    private String name ;
    private int priority ;
    task(String name,int priority){
        this.name=name;
        this.priority = priority;
    }
    public String getname(){
        return name;
    }
    public String toString(){
        return name+" "+priority;
    }
}
class priorityComparator implements Comparator<task>{
   public int compare(task e1,task e2){
       return e1.getname().compareTo(e2.getname());
   }
}
class main{
    public static void main(String[] args){
       Scanner sc = new Scanner(System.in);
       ArrayList<task> al = new ArrayList<>();
       while(sc.hasNext()){
            String s = sc.nextLine();
           if(!s.equals("Completed")){
              String[] arr = s.split(" ");
              String name = arr[0];
              int priority = Integer.parseInt(arr[1]);
              al.add(new task(name,priority));
           }
       }
        Collections.sort(al,new priorityComparator());
        for(task s: al){
             System.out.println(s);}
         
    }
}